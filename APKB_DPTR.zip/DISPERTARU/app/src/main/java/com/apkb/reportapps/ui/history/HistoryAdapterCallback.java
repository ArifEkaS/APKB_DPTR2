package com.apkb.reportapps.ui.history;

public interface HistoryAdapterCallback {
}
