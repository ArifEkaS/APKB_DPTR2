# Laporan-Masyarakat
Membuat Aplikasi Laporan Masyarakat

# Tutorial Build with Android Studio
https://youtu.be/bMa6C0TaIMo

# Tutorial Build with Step by Step
https://rivaldi48.blogspot.com/2022/02/tutorial-membuat-aplikasi-laporan-masyarakat-dengan-android-studio.html

<img src="https://blogger.googleusercontent.com/img/a/AVvXsEg5N1nUUoQJEld0LcEKhtebpoM_EXMU2vL1KLpKZBtN3VTBFOa5WoTK5tb3T4Hh5DTlhCS9V_2uv_9vLBlSm7Uie3aqw3oPzGZaLSHXZsgCObK2rVnNRcwuoLgVtdDFHGuOcNCV7UHN83Aa72g7zd0TtPrrbIsAECt10rF4jQLiGnZevcRBAgC7RaQ7LA=s1280" data-canonical-src="https://blogger.googleusercontent.com/img/a/AVvXsEg5N1nUUoQJEld0LcEKhtebpoM_EXMU2vL1KLpKZBtN3VTBFOa5WoTK5tb3T4Hh5DTlhCS9V_2uv_9vLBlSm7Uie3aqw3oPzGZaLSHXZsgCObK2rVnNRcwuoLgVtdDFHGuOcNCV7UHN83Aa72g7zd0TtPrrbIsAECt10rF4jQLiGnZevcRBAgC7RaQ7LA=s1280" style="max-width:100%;">

****If you use the Source Code, please make sure to credit and backlink to [Azhar Rivaldi](https://rivaldi48.blogspot.com/)***

## 👇 Click For Support Me :
<a href="https://sociabuzz.com/azharrvldi_/donate"> 
<img src="https://github.com/AzharRivaldi/AzharRivaldi/blob/master/Support%20Here.png" width="200" height="200"></a>

## 📄 License

```
Copyright (C) Azhar Rivaldi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.

```
